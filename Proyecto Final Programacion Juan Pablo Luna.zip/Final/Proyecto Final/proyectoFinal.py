from flask import Flask, request, g, redirect, url_for, render_template, flash, session
import flask
import sys
from flask import json
import ast
    
app = Flask(__name__)
app.config.from_envvar('FLASKR_SETTINGS', silent=True)
app.secret_key = 'random string'
options = []
c = []
usua = ''
@app.route('/register',methods=['GET', 'POST'])
def register():
    
    entries = {}
    return render_template('register.html')

    
@app.route('/register1',methods=['GET', 'POST']) #esta funcion es la que registra al usuario junto con sus preferencias, ingresa a pagina principal
def register1():
    global  usua,c
    test = []
    comprobador = False
    usua = str(request.form['Usuario'])
    contra = str(request.form['Contraseña'])  
    file = open("cuentas.txt","r+")
    test = file.readlines()
    i = 0
    for element in test:
        temp = test[i].split(" ")
        if temp[0] == usua:
            comprobador = True
        i = i + 1
    if(request.method == 'POST'):
        areo = str(request.form['areo'])
        horaS = str(request.form['HoraSalida'])
        numS = str(request.form['HoraSalidaNum'])
        horaL = str(request.form['HoraLlegada'])
        numL = str(request.form['HoraLlegadaNum'])
        conec = str(request.form['Numero de Conexiones'])
    temp1 = {'usuario':usua,'pref':{'areolinea':areo,'horaS':horaS,'numS':numS,'horaL':horaL,'numL':numL,'conecciones':conec}}
    if comprobador == False:    
        file.write("\n"+usua+" "+contra)
        file.close()
        temp = {'usuario':usua,'reservas':[]}
        with open('reservas.txt','r') as arch:
            c = ast.literal_eval(arch.read())
        arch.close()
        c.append(temp)
        with open('reservas.txt','w') as arch:
                arch.write(str(c))
                arch.close()
        with open('usuarioActual.txt','w') as arch:
                arch.write(usua)
                arch.close()
        with open('preferencias.txt','r') as arch:
                pref = ast.literal_eval(arch.read())
                arch.close()
        pref.append(temp1)
        with open('preferencias.txt','w') as arch:
                arch.write(str(pref))
                arch.close()
        return render_template('inicio.html')
    elif comprobador == True:
        file.close()
        return render_template('register.html')
        flash("Esta Usuario ya esta siendo utilizado")



@app.route('/login',methods=['GET', 'POST'])#esta funcion comprueba que el login del usuario es valido y lo ingresa a la pagina principal
def login():
    global c, usua
    file = open("cuentas.txt","r")
    i = 0
    test = file.readlines()

    if(request.method == 'POST'):
        usua = str(request.form['Usuario'])
        contra = str(request.form['Contraseña'])
    for element in test:
        temp = test[i].split(" ")
        cont1 = temp[1].strip("\n")
        if temp[0] == usua and cont1 == contra:
            with open('usuarioActual.txt','w') as arch:
                arch.write(usua)
                arch.close()

            return render_template('inicio.html')
        else:
            return render_template('login.html')
        i = i + 1    
    

@app.route('/', methods=['GET', 'POST'])
def main():
    """
    """
    entries = {}
            
    return render_template('login.html')


@app.route('/inicio',methods=['GET','POST'])#pagina de inicio con tres opciones: cerrar sesion, hacer una reserva o ver cuenta
def inicio():
    pass
@app.route('/reservar',methods=['GET','POST'])
def reservar():
    return render_template('reservas.html')
 
@app.route('/reserva',methods=['GET','POST'])#interfaz que hace todo lo que es filtrar la busqueda y guarda los codigos de vuelos para elegir
def reserva():
    global options, c
    options = []
    entries = {}
    if(request.method == 'POST'):
        salida = str(request.form.get('Salida'))
        llegada = str(request.form.get('Llegada'))
        areo = str(request.form.get('Areolinea'))
        horaSal = str(request.form.get('HoraSalida'))
        horaLle = str(request.form.get('HoraLlegada'))
        numSal = str(request.form.get('HoraSalidaNum'))
        numLle = str(request.form.get('HoraLlegadaNum'))
        conecciones = str(request.form.get('Numero de Conexiones'))
    options = []
    
    file = open("vuelos.txt","r")
    for line in file:
        temp = line
        temp = temp.split()
        reser = {}
        if temp[6] != '0' or temp[6] != '1' or temp[6] != '2' or temp[6] != '3' or temp[6] != '4':
            temp.pop(6)


        if salida == temp[2] and llegada== temp[4]:
            print ('hey')
            if areo != 'none' and areo == temp[0]:
                if numSal != "none":
                    numSal = int(numSal)
                    horaS=temp[3]
                    APS = horaS[-1]
                    horaS = horaS.strip(APS)
                    horaS = int(horaS)
                    if (numSal+60)>horaS and horaS >= numSal and APS == horaSal:
                        if numLle != "none":
                            numLle = int(numLle)
                            horaL=temp[5]
                            APL = horaL[-1]
                            horaL = horaL.strip(APL)
                            horaL = int(horaL)
                            if (numLle+60)>horaL and horaL >= numLle and APL == horaLle:
                                if temp[6] == conecciones:
                                    reser = {'vuelo':temp[1],'areolinea':temp[0],'salida':temp[2],'horaS':temp[3],'llegada':temp[4],'horaL':temp[5],'conec':temp[6]}
                                    options.append(reser)
                                elif conecciones == 'none':
                                    reser = {'vuelo':temp[1],'areolinea':temp[0],'salida':temp[2],'horaS':temp[3],'llegada':temp[4],'horaL':temp[5],'conec':temp[6]}
                                    options.append(reser)
                        elif numLle == "none":
                            if temp[6] == conecciones:
                                reser = {'vuelo':temp[1],'areolinea':temp[0],'salida':temp[2],'horaS':temp[3],'llegada':temp[4],'horaL':temp[5],'conec':temp[6]}
                                options.append(reser)
                            elif conecciones == 'none':
                                reser = {'vuelo':temp[1],'areolinea':temp[0],'salida':temp[2],'horaS':temp[3],'llegada':temp[4],'horaL':temp[5],'conec':temp[6]}
                                options.append(reser)
                elif numSal == "none":
                    if numLle != "none":
                            numLle = int(numLle)
                            horaL=temp[5]
                            APL = horaL[-1]
                            horaL = horaL.strip(APL)
                            horaL = int(horaL)
                            if (numLle+60)>horaL and horaL >= numLle and APL == horaLle:
                                if temp[6] == conecciones:
                                    reser = {'vuelo':temp[1],'areolinea':temp[0],'salida':temp[2],'horaS':temp[3],'llegada':temp[4],'horaL':temp[5],'conec':temp[6]}
                                    options.append(reser)
                                elif conecciones == 'none':
                                    reser = {'vuelo':temp[1],'areolinea':temp[0],'salida':temp[2],'horaS':temp[3],'llegada':temp[4],'horaL':temp[5],'conec':temp[6]}
                                    options.append(reser)
                            elif numLle == 'none':
                                if temp[6] == conecciones:
                                    reser = {'vuelo':temp[1],'areolinea':temp[0],'salida':temp[2],'horaS':temp[3],'llegada':temp[4],'horaL':temp[5],'conec':temp[6]}
                                    options.append(reser)
                                elif conecciones == 'none':
                                    reser = {'vuelo':temp[1],'areolinea':temp[0],'salida':temp[2],'horaS':temp[3],'llegada':temp[4],'horaL':temp[5],'conec':temp[6]}
                                    options.append(reser)

            elif areo == 'none':
                if numSal != 'none':
                    numSal = int(numSal)
                    horaS=temp[3]
                    APS = horaS[-1]
                    horaS = horaS.strip(APS)
                    horaS = int(horaS)
                    if (numSal+60)>horaS and horaS >= numSal and APS == horaSal:
                        if numLle != 'none':
                            numLle = int(numLle)
                            horaL=temp[5]
                            APL = horaL[-1]
                            horaL = horaL.strip(APL)
                            horaL = int(horaL)
                            if (numLle+60)>horaL and horaL >= numLle and APL == horaLle:
                                if temp[7] == conecciones:
                                    reser = {'vuelo':temp[1],'areolinea':temp[0],'salida':temp[2],'horaS':temp[3],'llegada':temp[4],'horaL':temp[5],'conec':temp[6]}
                                    options.append(reser)
                                elif conecciones == 'none':
                                    reser = {'vuelo':temp[1],'areolinea':temp[0],'salida':temp[2],'horaS':temp[3],'llegada':temp[4],'horaL':temp[5],'conec':temp[6]}
                                    options.append(reser)
                        elif numLle == 'none':
                            if temp[7] == conecciones:
                                reser = {'vuelo':temp[1],'areolinea':temp[0],'salida':temp[2],'horaS':temp[3],'llegada':temp[4],'horaL':temp[5],'conec':temp[6]}
                                options.append(reser)
                            elif conecciones == 'none':
                                reser = {'vuelo':temp[1],'areolinea':temp[0],'salida':temp[2],'horaS':temp[3],'llegada':temp[4],'horaL':temp[5],'conec':temp[6]}
                                options.append(reser)
                elif numSal == "none":
                    if numLle != "none":
                            numLle = int(numLle)
                            horaL=temp[5]
                            APL = horaL[-1]
                            horaL = horaL.strip(APL)
                            horaL = int(horaL)
                            if (numLle+60)>horaL and horaL >= numLle and APL == horaLle:
                                if temp[7] == conecciones:
                                    reser = {'vuelo':temp[1],'areolinea':temp[0],'salida':temp[2],'horaS':temp[3],'llegada':temp[4],'horaL':temp[5],'conec':temp[6]}
                                    options.append(reser)
                                elif conecciones == "none":
                                    reser = {'vuelo':temp[1],'areolinea':temp[0],'salida':temp[2],'horaS':temp[3],'llegada':temp[4],'horaL':temp[5],'conec':temp[6]}
                                    options.append(reser)
                    elif numLle == "none":
                            if temp[7] == conecciones:
                                reser = {'vuelo':temp[1],'areolinea':temp[0],'salida':temp[2],'horaS':temp[3],'llegada':temp[4],'horaL':temp[5],'conec':temp[6]}
                                options.append(reser)
                            elif conecciones == "none":
                                reser = {'vuelo':temp[1],'areolinea':temp[0],'salida':temp[2],'horaS':temp[3],'llegada':temp[4],'horaL':temp[5],'conec':temp[6]}
                                options.append(reser)
    file.close()
    print(temp[2])
    print(salida)
    print(llegada)
    print(options)
    entries['lista'] = options
    entries['numero'] = len(options)
    
    

    return render_template('elegir.html', entries = entries)

@app.route('/vuelos',methods=['GET','POST'])#interfaz que muestra todos los resultados de la busqueda y deja que el usuario elija una para almacenarla
def vuelos():
    global options, c
    with open('usuarioActual.txt','r') as arch:
                usua=arch.readline()
                arch.close()
    reser = str(request.form.get('lista'))
    print(reser)
    print(usua)
    file = open('vuelos.txt','r')
    for line in file:
        temp = line
        temp = temp.split()
        if temp[6] != '0' or temp[6] != '1' or temp[6] != '2' or temp[6] != '3' or temp[6] != '4':
            temp.pop(6)
        if temp[1]==reser:
            nueva = {'vuelo':temp[1],'areolinea':temp[0],'salida':temp[2],'horaS':temp[3],'llegada':temp[4],'horaL':temp[5],'conec':temp[6]}
            break
    file.close()
    with open('reservas.txt','r') as arch:
            c = ast.literal_eval(arch.read())
            i = 0
            while i < len(c):
                if c[i]['usuario']==usua:
                    c[i]['reservas'].append(nueva)
                i = i + 1
    arch.close()
    with open('reservas.txt','w') as arch:
        arch.write(str(c))
        arch.close()
    return render_template('inicio.html')
@app.route('/cuenta',methods=['GET','POST'])#lugar donde se puede acceder a las preferencias o ver las reservas hechs por el usuario
def cuenta():
    nuevo=[]
    with open('usuarioActual.txt','r') as arch:
                usua=arch.readline()
                arch.close()
    with open('reservas.txt','r') as arch:
            c = ast.literal_eval(arch.read())
            i = 0
            while i < len(c):
                if c[i]['usuario']==usua:
                    nuevo = c[i]['reservas']
                i = i + 1
    arch.close()
    entries={}
    entries['lista']=nuevo
    entries['numero']=len(nuevo)
    return render_template('/cuenta.html',entries=entries)

@app.route('/preferencias',methods=['GET','POST'])#lugar en el cual se pueden ver las preferencias del usuario
def preferencias():
    
    with open('usuarioActual.txt','r') as arch:
                usua = arch.readline()
                arch.close()
    with open('preferencias.txt','r') as arch:
                pref = ast.literal_eval(arch.read())
                arch.close()
    i = 0
    while i<len(pref):
        if pref[i]['usuario']== usua:
            temp = pref[i]['pref']
            break
        i = i +1
    entries = pref[i]['pref']
    return render_template('preferencias.html', entries=entries)
@app.route('/preferencias',methods=['GET','POST'])
def preferencias1():
    return render_template('preferencias.html', entries=entries)
@app.route('/volver',methods=['GET','POST'])
def volver():
    return render_template('inicio.html')

@app.route('/cambiar',methods=['GET','POST'])#boton con el cual se cambian las preferencias del usuarion por las nuevas registradas
def cambiar():
    with open('usuarioActual.txt','r') as arch:
            usua = arch.readline()
            arch.close()
    with open('preferencias.txt','r') as arch:
        pref = ast.literal_eval(arch.read())
        arch.close()
    i = 0
    while i<len(pref):
        if pref[i]['usuario']== usua:
            temp = pref[i]['pref']
            pref.pop(i)
            break
        i = i +1
    if(request.method == 'POST'):
        areo = str(request.form['areo'])
        horaS = str(request.form['HoraSalida'])
        numS = str(request.form['HoraSalidaNum'])
        horaL = str(request.form['HoraLlegada'])
        numL = str(request.form['HoraLlegadaNum'])
        conec = str(request.form['Numero de Conexiones'])
    temp1 = {'usuario':usua,'pref':{'areolinea':areo,'horaS':horaS,'numS':numS,'horaL':horaL,'numL':numL,'conecciones':conec}}
    pref.append(temp1)
    
    with open('preferencias.txt','w') as arch:
        arch.write(str(pref))
        arch.close()
    entries= {}
    return render_template('inicio.html', entries=entries)
@app.route('/cerrar',methods=['GET','POST'])#cierra cesion y lo devuelve al login
def cerrar():
    return render_template('login.html')

if __name__ == '__main__':
    app.run(debug = True)
